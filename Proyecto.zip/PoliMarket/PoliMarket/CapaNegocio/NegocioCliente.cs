﻿using System;
using System.Collections.Generic;
using System.Linq;
using CapaEntidad;

namespace CapaNegocio
{
    public class NegocioCliente
    {
        private List<Cliente> clientes = new List<Cliente>();
        private int ultimoId = 0;

        // Registrar cliente (genera ID único)
        public Cliente RegistrarCliente(string nombre, string apellido)
        {
            var nuevoCliente = new Cliente(++ultimoId, nombre, apellido);
            clientes.Add(nuevoCliente);
            return nuevoCliente;
        }

        // Actualizar cliente 
        public bool ActualizarCliente(Cliente clienteActualizado)
        {
            if (clienteActualizado == null)
                throw new ArgumentNullException(nameof(clienteActualizado));

            var cliente = clientes.FirstOrDefault(c => c.IdCliente == clienteActualizado.IdCliente);
            if (cliente == null)
                return false;

            cliente.ActualizarDatos(clienteActualizado.Nombre, clienteActualizado.Apellido);
            return true;
        }

        // Eliminar cliente
        public bool EliminarCliente(int id)
        {
            var cliente = clientes.FirstOrDefault(c => c.IdCliente == id);
            if (cliente == null)
                return false;

            clientes.Remove(cliente);
            return true;
        }

        // Buscar cliente por ID
        public Cliente BuscarPorId(int id)
        {
            return clientes.FirstOrDefault(c => c.IdCliente == id);
        }

        // Buscar clientes por nombre
        public List<Cliente> BuscarPorNombre(string nombre)
        {
            if (string.IsNullOrWhiteSpace(nombre))
                return new List<Cliente>();

            return clientes
                .Where(c => c.Nombre.IndexOf(nombre, StringComparison.OrdinalIgnoreCase) >= 0)
                .ToList();
        }

        // Listar todos los clientes
        public List<Cliente> ListarClientes()
        {
            return new List<Cliente>(clientes);
        }
    }
}
