﻿using System;
using System.Collections.Generic;
using System.Linq;
using CapaEntidad;

namespace CapaNegocio
{
    public class NegocioProducto
    {
        private List<Producto> productos = new List<Producto>();
        private int ultimoId = 0;

        // Registrar producto (genera ID único)
        public Producto RegistrarProducto(string nombre, double precio, int stock)
        {
            var nuevoProducto = new Producto(++ultimoId, nombre, precio, stock);
            productos.Add(nuevoProducto);
            return nuevoProducto;
        }

        // Actualizar producto (por objeto)
        public bool ActualizarProducto(Producto productoActualizado)
        {
            if (productoActualizado == null)
                throw new ArgumentNullException(nameof(productoActualizado));

            var producto = productos.FirstOrDefault(p => p.IdProducto == productoActualizado.IdProducto);
            if (producto == null)
                return false;

            producto.ActualizarDatos(productoActualizado.Nombre, productoActualizado.Precio, productoActualizado.Stock);
            return true;
        }

        // Eliminar producto
        public bool EliminarProducto(int id)
        {
            var producto = productos.FirstOrDefault(p => p.IdProducto == id);
            if (producto == null)
                return false;

            productos.Remove(producto);
            return true;
        }

        // Buscar producto por ID
        public Producto BuscarPorId(int id)
        {
            return productos.FirstOrDefault(p => p.IdProducto == id);
        }

        // Buscar productos por nombre 
        public List<Producto> BuscarPorNombre(string nombre)
        {
            if (string.IsNullOrWhiteSpace(nombre))
                return new List<Producto>();

            return productos
                .Where(p => p.Nombre.IndexOf(nombre, StringComparison.OrdinalIgnoreCase) >= 0)
                .ToList();
        }

        // Listar todos los productos
        public List<Producto> ListarProductos()
        {
            return new List<Producto>(productos);
        }
    }
}
