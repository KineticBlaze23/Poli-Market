﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaNegocio;
using CapaEntidad;

namespace CapaPresentacion
{
    public partial class FormCliente : Form
    {
        private NegocioCliente negocioCliente = new NegocioCliente();
        private List<Cliente> listaClientes;

        public FormCliente()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;

            // Configuración recomendada para el ListView
            listCliente.FullRowSelect = true;
            listCliente.MultiSelect = false;
            listCliente.View = View.Details;
            listCliente.SelectedIndexChanged += listCliente_SelectedIndexChanged;
        }

        private void FormCliente_Load(object sender, EventArgs e)
        {
            cmbBuscar.Items.Clear();
            cmbBuscar.Items.Add("ID");
            cmbBuscar.Items.Add("Nombre");
            cmbBuscar.SelectedIndex = 0; // Selecciona "ID" por defecto

            // Configura las columnas solo una vez
            listCliente.Columns.Clear();
            listCliente.Columns.Add("ID", 60);
            listCliente.Columns.Add("Nombre", 100);
            listCliente.Columns.Add("Apellido", 100);
            listCliente.Columns.Add("Cédula", 100);
            listCliente.Columns.Add("Correo", 150);
            listCliente.Columns.Add("Dirección", 150);

            ActualizarListaClientes();
        }

        private void btnRgresar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtxBNombre_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtxBApellido_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            string nombre = txtBNombre.Text.Trim();
            string apellido = txtBApellido.Text.Trim();
            string cedula = txtBCedula.Text.Trim();
            string correo = tctBCorreoElectronico.Text.Trim();
            string direccion = txtBDireccion.Text.Trim();

            if (string.IsNullOrEmpty(nombre) || string.IsNullOrEmpty(apellido) ||
                string.IsNullOrEmpty(cedula) || string.IsNullOrEmpty(correo) || string.IsNullOrEmpty(direccion))
            {
                MessageBox.Show("Debe ingresar todos los campos: nombre, apellido, cédula, correo electrónico y dirección.");
                return;
            }

            if (!CedulaValida(cedula))
            {
                MessageBox.Show("La cédula debe tener exactamente 10 dígitos numéricos.");
                return;
            }

            if (!CorreoValido(correo))
            {
                MessageBox.Show("El correo electrónico no tiene un formato válido (nombredeusuario@dominio.com).");
                return;
            }

            // Verificar duplicados por cédula o correo
            var existe = negocioCliente.ListarClientes()
                .Any(c => c.Cedula == cedula || c.CorreoElectronico == correo);

            if (existe)
            {
                MessageBox.Show("Ya existe un cliente con la misma cédula o correo electrónico.");
                return;
            }

            // Registrar solo nombre y apellido (según la firma actual)
            var cliente = negocioCliente.RegistrarCliente(nombre, apellido);

            // Asignar los demás datos
            cliente.Cedula = cedula;
            cliente.CorreoElectronico = correo;
            cliente.Direccion = direccion;

            ActualizarListaClientes();

            // Mensaje de confirmación
            MessageBox.Show("Cliente agregado correctamente.");

            // Limpiar campos después de agregar
            txtBNombre.Clear();
            txtBApellido.Clear();
            txtBCedula.Clear();
            tctBCorreoElectronico.Clear();
            txtBDireccion.Clear();
            txtBNombre.Focus();
        }

        private void ActualizarListaClientes()
        {
            listCliente.Items.Clear();
            foreach (var cliente in negocioCliente.ListarClientes())
            {
                ListViewItem item = new ListViewItem(cliente.IdCliente.ToString());
                item.SubItems.Add(cliente.Nombre);
                item.SubItems.Add(cliente.Apellido);
                item.SubItems.Add(cliente.Cedula);
                item.SubItems.Add(cliente.CorreoElectronico);
                item.SubItems.Add(cliente.Direccion);

                listCliente.Items.Add(item);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string filtro = txtFiltrar.Text.ToLower();

            var listaClientes = negocioCliente.ListarClientes();

            var listaFiltrada = listaClientes
                .Where(c => c.Nombre.ToLower().Contains(filtro))
                .ToList();

            ActualizarListaClientesFiltrados(listaFiltrada);
        }

        private void ActualizarListaClientesFiltrados(List<Cliente> listaFiltrada)
        {
            listCliente.Items.Clear();
            foreach (var cliente in listaFiltrada)
            {
                ListViewItem item = new ListViewItem(cliente.IdCliente.ToString());
                item.SubItems.Add(cliente.Nombre);
                item.SubItems.Add(cliente.Apellido);
                item.SubItems.Add(cliente.Cedula);
                item.SubItems.Add(cliente.CorreoElectronico);
                item.SubItems.Add(cliente.Direccion);

                listCliente.Items.Add(item);
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (listCliente.SelectedItems.Count == 0)
            {
                MessageBox.Show("Seleccione un cliente para eliminar.");
                return;
            }

            var confirmResult = MessageBox.Show(
                "¿Está seguro que desea eliminar el cliente seleccionado?",
                "Confirmar eliminación",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (confirmResult == DialogResult.Yes)
            {
                // Obtener el ID del cliente seleccionado
                int idCliente = int.Parse(listCliente.SelectedItems[0].SubItems[0].Text);

                bool eliminado = negocioCliente.EliminarCliente(idCliente);

                if (eliminado)
                {
                    MessageBox.Show("Cliente eliminado correctamente.");
                    ActualizarListaClientes();

                    // Limpiar campos después de eliminar
                    txtBNombre.Clear();
                    txtBApellido.Clear();
                    txtBCedula.Clear();
                    tctBCorreoElectronico.Clear();
                    txtBDireccion.Clear();
                }
                else
                {
                    MessageBox.Show("No se pudo eliminar el cliente.");
                }
            }
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            if (listCliente.SelectedItems.Count == 0)
            {
                MessageBox.Show("Seleccione un cliente para modificar.");
                return;
            }

            // Obtener el ID del cliente seleccionado
            int idCliente = int.Parse(listCliente.SelectedItems[0].SubItems[0].Text);

            // Obtener los datos de los TextBox
            string nombre = txtBNombre.Text;
            string apellido = txtBApellido.Text;
            string cedula = txtBCedula.Text;
            string correo = tctBCorreoElectronico.Text;
            string direccion = txtBDireccion.Text;

            // Validar campos
            if (string.IsNullOrEmpty(nombre) || string.IsNullOrEmpty(apellido) ||
                string.IsNullOrEmpty(cedula) || string.IsNullOrEmpty(correo) || string.IsNullOrEmpty(direccion))
            {
                MessageBox.Show("Debe ingresar todos los campos: nombre, apellido, cédula, correo electrónico y dirección.");
                return;
            }

            if (!CedulaValida(cedula))
            {
                MessageBox.Show("La cédula debe tener exactamente 10 dígitos numéricos.");
                return;
            }

            if (!CorreoValido(correo))
            {
                MessageBox.Show("El correo electrónico no tiene un formato válido (nombredeusuario@dominio.com).");
                return;
            }

            // Buscar el cliente original y actualizar sus datos
            Cliente clienteOriginal = negocioCliente.BuscarPorId(idCliente);
            if (clienteOriginal != null)
            {
                clienteOriginal.Nombre = nombre;
                clienteOriginal.Apellido = apellido;
                clienteOriginal.Cedula = cedula;
                clienteOriginal.CorreoElectronico = correo;
                clienteOriginal.Direccion = direccion;

                bool actualizado = negocioCliente.ActualizarCliente(clienteOriginal);

                if (actualizado)
                {
                    MessageBox.Show("Cliente modificado correctamente.");
                    ActualizarListaClientes();
                }
                else
                {
                    MessageBox.Show("No se pudo modificar el cliente.");
                }
            }
            else
            {
                MessageBox.Show("No se encontró el cliente a modificar.");
            }
        }

        private void cmbBuscar_SelectedIndexChanged(object sender, EventArgs e)
        {
            string opcion = cmbBuscar.SelectedItem?.ToString();
            string filtro = txtFiltrar.Text.Trim();

            if (string.IsNullOrEmpty(opcion) || string.IsNullOrEmpty(filtro))
            {
                // Si no hay filtro, mostrar todos los clientes
                ActualizarListaClientes();
                return;
            }

            List<Cliente> resultado = new List<Cliente>();

            if (opcion == "ID")
            {
                int id;
                if (int.TryParse(filtro, out id))
                {
                    var cliente = negocioCliente.BuscarPorId(id);
                    if (cliente != null)
                        resultado.Add(cliente);
                }
                // Si no es un número válido, resultado queda vacío
            }
            else if (opcion == "Nombre")
            {
                resultado = negocioCliente.BuscarPorNombre(filtro);
            }

            ActualizarListaClientesFiltrados(resultado);
        }

        private void listCliente_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listCliente.SelectedItems.Count == 0)
                return;

            var item = listCliente.SelectedItems[0];
            txtBNombre.Text = item.SubItems[1].Text;
            txtBApellido.Text = item.SubItems[2].Text;
            txtBCedula.Text = item.SubItems[3].Text;
            tctBCorreoElectronico.Text = item.SubItems[4].Text;
            txtBDireccion.Text = item.SubItems[5].Text;
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private bool CedulaValida(string cedula)
        {
            return cedula.Length == 10 && cedula.All(char.IsDigit);
        }

        private bool CorreoValido(string correo)
        {
            // Validación básica de correo: usuario@dominio.com
            try
            {
                var addr = new System.Net.Mail.MailAddress(correo);
                return addr.Address == correo;
            }
            catch
            {
                return false;
            }
        }
    }
}
