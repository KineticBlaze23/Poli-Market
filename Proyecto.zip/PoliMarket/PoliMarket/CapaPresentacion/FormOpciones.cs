﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class FormOpciones : Form
    {
        public FormOpciones()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void btnVenta_Click(object sender, EventArgs e)
        {
            this.Hide();
            var formVenta = new FormVenta();
            formVenta.ShowDialog();
            this.Show();
        }

        private void btnProducto_Click(object sender, EventArgs e)
        {
            this.Hide();
            var formProducto = new FormProducto();
            formProducto.ShowDialog();
            this.Show();
        }

        private void btnCliente_Click(object sender, EventArgs e)
        {
            this.Hide();
            var formCliente = new FormCliente();
            formCliente.ShowDialog();
            this.Show();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void FormOpciones_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
