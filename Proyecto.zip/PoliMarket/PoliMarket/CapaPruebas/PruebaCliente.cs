﻿using System;
using CapaNegocio;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CapaPruebas
{
    [TestClass]
    public class PruebaCliente
    {
       
           
           
            [TestMethod]
            public void RegistrarCliente()
            {
                // Arrange
                var negocio = new NegocioCliente();

                // Act
                var cliente1 = negocio.RegistrarCliente("Carlos", "Ramírez");
                var cliente2 = negocio.RegistrarCliente("Laura", "Díaz");

                // Assert
                Assert.AreEqual(1, cliente1.IdCliente);
                Assert.AreEqual("Carlos", cliente1.Nombre);
                Assert.AreEqual("Ramírez", cliente1.Apellido);

                Assert.AreEqual(2, cliente2.IdCliente);
                Assert.AreEqual("Laura", cliente2.Nombre);
                Assert.AreEqual("Díaz", cliente2.Apellido);
            }
    }
}
